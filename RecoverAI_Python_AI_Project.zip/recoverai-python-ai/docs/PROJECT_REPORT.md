# RecoverAI Project Report

## Abstract
RecoverAI is a Python-based AI decision-support prototype for revenue recovery. It scores the probability that a failed payment will remain unrecovered, identifies observable risk signals, and recommends a next step subject to policy safeguards.

## Problem statement
Payment failures and abandoned checkouts can create revenue leakage. Teams need to prioritize cases while avoiding repetitive or inappropriate customer contact. RecoverAI demonstrates how a predictive model and deterministic policy engine can support this workflow.

## Objectives
1. Generate reproducible training data for development.
2. Train and persist a machine-learning classifier.
3. Validate incoming cases through typed API schemas.
4. Return risk scores, risk bands, risk signals, and next-step recommendations.
5. Enforce stop conditions for completed payments, opt-outs, and contact limits.
6. Store cases and simulated outcomes for traceability.
7. Provide a dashboard and automated tests.

## Technology stack
Python, pandas, NumPy, scikit-learn, FastAPI, Pydantic, SQLite, Streamlit, pytest, Docker, GitHub Actions.

## Methodology
A Random Forest classifier is trained on generated synthetic examples. Numeric features are imputed and scaled; categorical fields are imputed and one-hot encoded. The model returns a probability score. A separate policy module determines the permitted recommendation, so deterministic safeguards override the model.

## Evaluation
The training script reports ROC-AUC and a classification report on a held-out split. Since the dataset is synthetic, these metrics only verify the training pipeline and must not be interpreted as evidence of real-world performance. A real deployment requires a representative, authorized, time-aware dataset and ongoing monitoring.

## Limitations and future work
- Synthetic data is not representative of any real payment processor.
- No payment gateway or messaging provider is connected.
- Risk-factor explanations are rule-based signals, not formal causal explanations.
- Future improvements: probability calibration, temporal validation, drift monitoring, model cards, authentication, role-based access, and integration tests against a sandbox payment provider.
