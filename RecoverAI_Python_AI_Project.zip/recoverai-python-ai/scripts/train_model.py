import json
from app.config import ARTIFACTS_DIR, DATA_DIR, MODEL_PATH
from app.model import train_model, save_model
from app.synthetic_data import generate_dataset

def main():
    dataset_path = DATA_DIR / "synthetic_recovery_training.csv"
    metrics_path = ARTIFACTS_DIR / "training_metrics.json"
    df = generate_dataset(rows=6000, seed=42)
    df.to_csv(dataset_path, index=False)
    model, metrics = train_model(df)
    save_model(model, MODEL_PATH)
    metrics_path.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(f"Dataset: {dataset_path}")
    print(f"Model:   {MODEL_PATH}")
    print(f"Metrics: {metrics_path}")
    print(f"ROC-AUC: {metrics['roc_auc']}")
    print("Reminder: metrics use synthetic data and do not represent real-world performance.")

if __name__ == "__main__":
    main()
