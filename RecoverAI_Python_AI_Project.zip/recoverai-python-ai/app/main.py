import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, Query
from app.config import LOG_LEVEL
from app.database import init_db, create_case, get_case, list_cases, simulate_recovery
from app.schemas import PaymentCaseInput, PredictionResponse, RecoverySimulationInput
from app.service import predict_case, get_model

logging.basicConfig(level=LOG_LEVEL, format="%(asctime)s %(levelname)s %(name)s %(message)s")
logger = logging.getLogger("recoverai")

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield

app = FastAPI(title="RecoverAI API", version="1.0.0",
              description="AI-assisted revenue recovery risk scoring and policy-based recommendations.",
              lifespan=lifespan)

@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": get_model() is not None, "service": "RecoverAI"}

@app.post("/predict", response_model=PredictionResponse)
def predict(payload: PaymentCaseInput):
    try:
        return predict_case(payload.model_dump())
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception:
        logger.exception("Prediction failed")
        raise HTTPException(status_code=500, detail="Prediction failed. Check service logs.")

@app.post("/cases")
def create_recovery_case(payload: PaymentCaseInput):
    case = payload.model_dump()
    try:
        prediction = predict_case(case)
        saved = create_case(case, prediction)
        logger.info("Created recovery case id=%s action=%s", saved["id"], prediction["recommended_action"])
        return saved
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

@app.get("/cases")
def cases(limit: int = Query(default=50, ge=1, le=200)):
    items = list_cases(limit)
    return {"items": items, "count": len(items)}

@app.get("/cases/{case_id}")
def case_detail(case_id: int):
    result = get_case(case_id)
    if result is None:
        raise HTTPException(status_code=404, detail="Case not found")
    return result

@app.post("/cases/{case_id}/simulate-recovery")
def recovery_result(case_id: int, payload: RecoverySimulationInput):
    result = simulate_recovery(case_id, payload.recovered, payload.note)
    if result is None:
        raise HTTPException(status_code=404, detail="Case not found")
    return result
