from enum import Enum
from pydantic import BaseModel, Field, ConfigDict

class PaymentMethod(str, Enum):
    card = "card"
    upi = "upi"
    wallet = "wallet"
    bank_transfer = "bank_transfer"
    other = "other"

class FailureCode(str, Enum):
    insufficient_funds = "insufficient_funds"
    do_not_honor = "do_not_honor"
    expired_card = "expired_card"
    network_error = "network_error"
    authentication_required = "authentication_required"
    unknown = "unknown"

class PaymentCaseInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    amount: float = Field(ge=0, le=100_000_000)
    payment_attempts: int = Field(ge=0, le=100)
    hours_since_failure: float = Field(ge=0, le=100_000)
    customer_tenure_days: int = Field(ge=0, le=100_000)
    previous_success_rate: float = Field(ge=0, le=1)
    is_subscription: bool
    invoice_age_days: int = Field(ge=0, le=10_000)
    cart_value: float = Field(ge=0, le=100_000_000)
    payment_method: PaymentMethod = PaymentMethod.card
    failure_code: FailureCode = FailureCode.unknown
    contact_count_24h: int = Field(ge=0, le=100)
    customer_opted_out: bool = False
    payment_already_succeeded: bool = False

class PredictionResponse(BaseModel):
    risk_probability: float
    risk_band: str
    likely_to_fail_recovery: bool
    risk_factors: list[str]
    recommended_action: str
    action_reason: str
    estimated_at_risk_amount: float
    model_version: str

class RecoverySimulationInput(BaseModel):
    recovered: bool
    note: str = Field(default="", max_length=500)
