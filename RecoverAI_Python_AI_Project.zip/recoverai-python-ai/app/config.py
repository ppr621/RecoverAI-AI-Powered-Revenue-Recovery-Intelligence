from pathlib import Path
import os

BASE_DIR = Path(__file__).resolve().parent.parent
ARTIFACTS_DIR = BASE_DIR / "artifacts"
DATA_DIR = BASE_DIR / "data"
DB_PATH = Path(os.getenv("RECOVERAI_DB_PATH", str(BASE_DIR / "recoverai.db")))
MODEL_PATH = Path(os.getenv("RECOVERAI_MODEL_PATH", str(ARTIFACTS_DIR / "recovery_model.joblib")))
LOG_LEVEL = os.getenv("RECOVERAI_LOG_LEVEL", "INFO").upper()
MAX_CONTACTS_24H = int(os.getenv("RECOVERAI_MAX_CONTACTS_24H", "2"))
ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)
DATA_DIR.mkdir(parents=True, exist_ok=True)
