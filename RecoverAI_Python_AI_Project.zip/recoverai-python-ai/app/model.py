from pathlib import Path
from typing import Any
import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.metrics import roc_auc_score, classification_report
from sklearn.model_selection import train_test_split

NUMERIC_FEATURES = [
    "amount", "payment_attempts", "hours_since_failure",
    "customer_tenure_days", "previous_success_rate",
    "invoice_age_days", "cart_value", "contact_count_24h"
]
CATEGORICAL_FEATURES = ["payment_method", "failure_code", "is_subscription"]
FEATURES = NUMERIC_FEATURES + CATEGORICAL_FEATURES
TARGET = "recovery_failed"

def build_pipeline() -> Pipeline:
    numeric = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])
    categorical = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("encoder", OneHotEncoder(handle_unknown="ignore")),
    ])
    preprocessor = ColumnTransformer([
        ("numeric", numeric, NUMERIC_FEATURES),
        ("categorical", categorical, CATEGORICAL_FEATURES),
    ])
    classifier = RandomForestClassifier(
        n_estimators=250, max_depth=10, min_samples_leaf=3,
        class_weight="balanced", random_state=42, n_jobs=-1
    )
    return Pipeline([("preprocessor", preprocessor), ("classifier", classifier)])

def train_model(df: pd.DataFrame) -> tuple[Pipeline, dict[str, Any]]:
    missing = set(FEATURES + [TARGET]) - set(df.columns)
    if missing:
        raise ValueError(f"Training data is missing columns: {sorted(missing)}")
    if df[TARGET].nunique() < 2:
        raise ValueError("Training data must contain both target classes.")
    X, y = df[FEATURES], df[TARGET].astype(int)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    model = build_pipeline()
    model.fit(X_train, y_train)
    probabilities = model.predict_proba(X_test)[:, 1]
    predictions = (probabilities >= 0.5).astype(int)
    metrics = {
        "roc_auc": round(float(roc_auc_score(y_test, probabilities)), 4),
        "classification_report": classification_report(
            y_test, predictions, output_dict=True, zero_division=0
        ),
        "train_rows": int(len(X_train)),
        "test_rows": int(len(X_test)),
    }
    return model, metrics

def load_model(path: Path):
    if not path.exists():
        return None
    return joblib.load(path)

def save_model(model, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, path)

def model_probability(model, features: dict[str, Any]) -> float:
    row = pd.DataFrame([{name: features[name] for name in FEATURES}])
    return float(model.predict_proba(row)[0, 1])
