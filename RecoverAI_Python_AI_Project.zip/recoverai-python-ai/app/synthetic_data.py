# Generate deterministic synthetic payment recovery data for a safe demo.
import numpy as np
import pandas as pd

PAYMENT_METHODS = ["card", "upi", "wallet", "bank_transfer", "other"]
FAILURE_CODES = [
    "insufficient_funds", "do_not_honor", "expired_card",
    "network_error", "authentication_required", "unknown"
]

def generate_dataset(rows: int = 5000, seed: int = 42) -> pd.DataFrame:
    if rows < 200:
        raise ValueError("Use at least 200 rows for a useful demo model.")
    rng = np.random.default_rng(seed)
    amount = np.round(rng.lognormal(mean=7.2, sigma=1.0, size=rows), 2).clip(0, 500_000)
    attempts = rng.poisson(1.1, rows).clip(0, 8)
    hours = np.round(rng.exponential(20, rows), 2).clip(0, 720)
    tenure = rng.integers(0, 2500, rows)
    success_rate = np.round(rng.beta(7, 2, rows), 3)
    subscription = rng.choice([True, False], rows, p=[0.45, 0.55])
    invoice_age = rng.integers(0, 120, rows)
    cart_value = np.round(amount * rng.uniform(0.6, 1.3, rows), 2)
    method = rng.choice(PAYMENT_METHODS, rows)
    failure = rng.choice(FAILURE_CODES, rows, p=[0.18, 0.25, 0.12, 0.2, 0.13, 0.12])
    contacts = rng.integers(0, 4, rows)
    logit = (
        -1.7 + 0.42 * attempts + 0.012 * np.minimum(hours, 100)
        + 1.4 * (1 - success_rate) + 0.025 * np.minimum(invoice_age, 60)
        + 0.5 * (failure == "expired_card")
        + 0.35 * (failure == "insufficient_funds")
        + 0.2 * (method == "bank_transfer")
        - 0.00015 * np.minimum(tenure, 2000)
        - 0.55 * subscription + 0.28 * contacts + rng.normal(0, 0.45, rows)
    )
    probability = 1 / (1 + np.exp(-logit))
    target = rng.binomial(1, probability)
    return pd.DataFrame({
        "amount": amount, "payment_attempts": attempts,
        "hours_since_failure": hours, "customer_tenure_days": tenure,
        "previous_success_rate": success_rate, "is_subscription": subscription,
        "invoice_age_days": invoice_age, "cart_value": cart_value,
        "payment_method": method, "failure_code": failure,
        "contact_count_24h": contacts, "recovery_failed": target,
    })
