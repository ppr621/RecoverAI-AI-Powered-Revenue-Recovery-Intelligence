from app.config import MAX_CONTACTS_24H

def explain_risk(case: dict) -> list[str]:
    factors = []
    if case["payment_attempts"] >= 3:
        factors.append("Multiple payment attempts have already failed")
    if case["previous_success_rate"] < 0.55:
        factors.append("Historical payment success rate is low")
    if case["hours_since_failure"] > 24:
        factors.append("The payment failure is more than 24 hours old")
    if case["failure_code"] == "expired_card":
        factors.append("The payment method may need updating")
    if case["failure_code"] == "authentication_required":
        factors.append("Additional authentication may be required")
    if case["invoice_age_days"] > 30:
        factors.append("The invoice is overdue by more than 30 days")
    if case["contact_count_24h"] > 0:
        factors.append("The customer has already received a recent recovery contact")
    return factors or ["No strong rule-based risk signals; review the case context"]

def recommend_action(case: dict, probability: float) -> tuple[str, str]:
    if case["payment_already_succeeded"]:
        return "stop", "Payment is already confirmed successful."
    if case["customer_opted_out"]:
        return "stop", "Customer opted out; no recovery contact should be made."
    if case["contact_count_24h"] >= MAX_CONTACTS_24H:
        return "wait", f"Contact limit reached ({MAX_CONTACTS_24H} in 24 hours)."
    if case["failure_code"] == "expired_card":
        return "update_payment_method", "Ask the customer to securely update their payment method."
    if case["failure_code"] == "authentication_required":
        return "authentication_help", "Provide a secure route to complete authentication."
    if probability >= 0.7:
        return "human_review", "High predicted recovery-failure risk; review before contacting."
    if probability >= 0.4:
        return "send_one_reminder", "Moderate risk; one polite, compliant reminder may be appropriate."
    return "retry_later", "Lower predicted risk; consider one delayed retry if allowed by provider policy."
