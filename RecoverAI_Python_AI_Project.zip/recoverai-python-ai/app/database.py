import json
import sqlite3
from datetime import datetime, timezone
from app.config import DB_PATH

def _connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with _connect() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS cases (
            id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL,
            status TEXT NOT NULL, input_json TEXT NOT NULL, prediction_json TEXT NOT NULL
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS audit_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT, case_id INTEGER,
            created_at TEXT NOT NULL, event_type TEXT NOT NULL, details_json TEXT NOT NULL,
            FOREIGN KEY(case_id) REFERENCES cases(id)
        )""")

def create_case(case: dict, prediction: dict) -> dict:
    created_at = datetime.now(timezone.utc).isoformat()
    with _connect() as conn:
        cursor = conn.execute(
            "INSERT INTO cases(created_at,status,input_json,prediction_json) VALUES(?,?,?,?)",
            (created_at, "open", json.dumps(case), json.dumps(prediction))
        )
        case_id = int(cursor.lastrowid)
        conn.execute(
            "INSERT INTO audit_events(case_id,created_at,event_type,details_json) VALUES(?,?,?,?)",
            (case_id, created_at, "case_created",
             json.dumps({"action": prediction["recommended_action"]}))
        )
    return {"id": case_id, "created_at": created_at, "status": "open", "input": case, "prediction": prediction}

def get_case(case_id: int):
    with _connect() as conn:
        row = conn.execute("SELECT * FROM cases WHERE id=?", (case_id,)).fetchone()
    if not row:
        return None
    return {"id": row["id"], "created_at": row["created_at"], "status": row["status"],
            "input": json.loads(row["input_json"]), "prediction": json.loads(row["prediction_json"])}

def list_cases(limit: int = 100):
    with _connect() as conn:
        rows = conn.execute("SELECT * FROM cases ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [{"id": r["id"], "created_at": r["created_at"], "status": r["status"],
             "input": json.loads(r["input_json"]), "prediction": json.loads(r["prediction_json"])}
            for r in rows]

def simulate_recovery(case_id: int, recovered: bool, note: str):
    timestamp = datetime.now(timezone.utc).isoformat()
    status = "recovered" if recovered else "not_recovered"
    with _connect() as conn:
        row = conn.execute("SELECT id FROM cases WHERE id=?", (case_id,)).fetchone()
        if not row:
            return None
        conn.execute("UPDATE cases SET status=? WHERE id=?", (status, case_id))
        conn.execute(
            "INSERT INTO audit_events(case_id,created_at,event_type,details_json) VALUES(?,?,?,?)",
            (case_id, timestamp, "recovery_simulated",
             json.dumps({"recovered": recovered, "note": note}))
        )
    return get_case(case_id)
