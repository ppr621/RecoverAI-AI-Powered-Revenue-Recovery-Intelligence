from app.config import MODEL_PATH
from app.model import load_model, model_probability
from app.policy import explain_risk, recommend_action

MODEL_VERSION = "recoverai-rf-v1"

def get_model():
    return load_model(MODEL_PATH)

def predict_case(case: dict, model=None) -> dict:
    model = model or get_model()
    if model is None:
        raise RuntimeError("Model not found. Run: python scripts/train_model.py")
    probability = model_probability(model, case)
    action, reason = recommend_action(case, probability)
    return {
        "risk_probability": round(probability, 4),
        "risk_band": "high" if probability >= 0.7 else "medium" if probability >= 0.4 else "low",
        "likely_to_fail_recovery": bool(probability >= 0.5),
        "risk_factors": explain_risk(case),
        "recommended_action": action,
        "action_reason": reason,
        "estimated_at_risk_amount": round(float(case["amount"]) * probability, 2),
        "model_version": MODEL_VERSION,
    }
