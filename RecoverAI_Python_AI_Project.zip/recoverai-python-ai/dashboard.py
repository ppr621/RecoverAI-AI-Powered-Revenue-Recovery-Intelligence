import requests
import streamlit as st

st.set_page_config(page_title="RecoverAI Dashboard", page_icon="💳", layout="wide")
st.title("RecoverAI — Revenue Recovery Intelligence")
st.caption("Demo dashboard · Synthetic-model predictions · No payments or messages are sent")
api_url = st.sidebar.text_input("API base URL", "http://127.0.0.1:8000").rstrip("/")

with st.sidebar.form("prediction_form"):
    st.subheader("Analyze a payment")
    amount = st.number_input("Payment amount", min_value=0.0, value=2499.0, step=100.0)
    attempts = st.number_input("Payment attempts", min_value=0, max_value=100, value=2)
    hours = st.number_input("Hours since failure", min_value=0.0, value=18.0)
    tenure = st.number_input("Customer tenure (days)", min_value=0, value=240)
    success_rate = st.slider("Previous success rate", 0.0, 1.0, 0.72)
    subscription = st.checkbox("Subscription payment", value=True)
    invoice_age = st.number_input("Invoice age (days)", min_value=0, value=0)
    cart_value = st.number_input("Cart value", min_value=0.0, value=2499.0)
    method = st.selectbox("Payment method", ["card", "upi", "wallet", "bank_transfer", "other"])
    failure = st.selectbox("Failure code", [
        "insufficient_funds", "do_not_honor", "expired_card",
        "network_error", "authentication_required", "unknown"
    ])
    contacts = st.number_input("Contacts in last 24 hours", min_value=0, max_value=100, value=0)
    opted_out = st.checkbox("Customer opted out")
    succeeded = st.checkbox("Payment already succeeded")
    submitted = st.form_submit_button("Predict risk")

if submitted:
    payload = {
        "amount": amount, "payment_attempts": attempts, "hours_since_failure": hours,
        "customer_tenure_days": tenure, "previous_success_rate": success_rate,
        "is_subscription": subscription, "invoice_age_days": invoice_age,
        "cart_value": cart_value, "payment_method": method, "failure_code": failure,
        "contact_count_24h": contacts, "customer_opted_out": opted_out,
        "payment_already_succeeded": succeeded
    }
    try:
        response = requests.post(f"{api_url}/predict", json=payload, timeout=10)
        response.raise_for_status()
        result = response.json()
        col1, col2, col3 = st.columns(3)
        col1.metric("Recovery-failure risk", f"{result['risk_probability']:.1%}")
        col2.metric("Risk band", result["risk_band"].upper())
        col3.metric("Estimated at-risk amount", f"{result['estimated_at_risk_amount']:,.2f}")
        st.subheader("Recommended action")
        st.success(result["recommended_action"].replace("_", " ").title())
        st.write(result["action_reason"])
        st.subheader("Risk signals")
        for factor in result["risk_factors"]:
            st.write(f"- {factor}")
        st.caption(f"Model: {result['model_version']}")
    except requests.RequestException as exc:
        st.error(f"Could not reach the API. Start it with `uvicorn app.main:app --reload`. Details: {exc}")

st.divider()
st.subheader("Saved cases")
if st.button("Refresh cases"):
    try:
        response = requests.get(f"{api_url}/cases", timeout=10)
        response.raise_for_status()
        data = response.json()
        st.write(f"Cases found: {data['count']}")
        if data["items"]:
            st.dataframe([{
                "id": c["id"], "created_at": c["created_at"], "status": c["status"],
                "risk": c["prediction"]["risk_band"],
                "probability": c["prediction"]["risk_probability"],
                "action": c["prediction"]["recommended_action"],
                "amount": c["input"]["amount"],
            } for c in data["items"]], use_container_width=True)
        else:
            st.info("No cases saved yet. Use the API POST /cases endpoint to save a case.")
    except requests.RequestException as exc:
        st.error(f"Could not load cases: {exc}")
