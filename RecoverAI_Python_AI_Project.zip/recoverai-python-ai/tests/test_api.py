from fastapi.testclient import TestClient
from app.main import app
from app.service import predict_case
from app.synthetic_data import generate_dataset
from app.model import train_model

def test_health_endpoint():
    client = TestClient(app)
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_prediction_response_shape():
    model, _ = train_model(generate_dataset(rows=500))
    case = {
        "amount": 2499.0, "payment_attempts": 3, "hours_since_failure": 18.0,
        "customer_tenure_days": 240, "previous_success_rate": 0.72,
        "is_subscription": True, "invoice_age_days": 0, "cart_value": 2499.0,
        "payment_method": "card", "failure_code": "do_not_honor",
        "contact_count_24h": 0, "customer_opted_out": False,
        "payment_already_succeeded": False,
    }
    result = predict_case(case, model=model)
    assert 0 <= result["risk_probability"] <= 1
    assert result["risk_band"] in {"low", "medium", "high"}
    assert result["recommended_action"]
