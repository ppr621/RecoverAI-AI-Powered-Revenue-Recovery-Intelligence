from app.policy import recommend_action, explain_risk

def base_case():
    return {
        "amount": 1000, "payment_attempts": 1, "hours_since_failure": 2,
        "customer_tenure_days": 200, "previous_success_rate": 0.8,
        "is_subscription": True, "invoice_age_days": 1, "cart_value": 1000,
        "payment_method": "card", "failure_code": "unknown",
        "contact_count_24h": 0, "customer_opted_out": False,
        "payment_already_succeeded": False,
    }

def test_successful_payment_stops_recovery():
    case = base_case()
    case["payment_already_succeeded"] = True
    assert recommend_action(case, 0.9)[0] == "stop"

def test_opt_out_stops_recovery():
    case = base_case()
    case["customer_opted_out"] = True
    assert recommend_action(case, 0.9)[0] == "stop"

def test_contact_cap_prevents_more_contact():
    case = base_case()
    case["contact_count_24h"] = 2
    assert recommend_action(case, 0.2)[0] == "wait"

def test_expired_card_recommends_update():
    case = base_case()
    case["failure_code"] = "expired_card"
    assert recommend_action(case, 0.1)[0] == "update_payment_method"

def test_explain_risk_returns_signal():
    case = base_case()
    case["payment_attempts"] = 3
    assert any("attempts" in signal.lower() for signal in explain_risk(case))
