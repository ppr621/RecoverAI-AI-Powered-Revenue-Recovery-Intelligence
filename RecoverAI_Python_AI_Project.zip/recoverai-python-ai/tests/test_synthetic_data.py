from app.synthetic_data import generate_dataset
from app.model import FEATURES, TARGET

def test_synthetic_dataset_has_expected_columns_and_classes():
    df = generate_dataset(rows=500, seed=5)
    assert set(FEATURES + [TARGET]).issubset(df.columns)
    assert len(df) == 500
    assert df[TARGET].nunique() == 2
