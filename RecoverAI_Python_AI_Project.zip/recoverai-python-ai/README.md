# RecoverAI — AI-Powered Revenue Recovery Intelligence

A portfolio-ready Python + AI project that identifies payment cases at risk, explains risk signals, and recommends compliant recovery actions. It includes a trainable machine-learning model, policy safeguards, FastAPI REST API, Streamlit dashboard, SQLite persistence, audit events, tests, Docker support, and GitHub Actions CI.

> **Demo notice:** The training data is synthetic. Predictions are decision-support signals, not guarantees of recovered revenue. This demo does not contact customers or process payments.

## Features
- Reproducible synthetic training-data generator
- Scikit-learn classification pipeline and model persistence
- Risk score, risk band, risk signals, and estimated at-risk amount
- Recovery action recommendations with stopping rules and contact limits
- SQLite case store and audit trail
- FastAPI endpoints for prediction, case creation, listing, and simulated outcomes
- Streamlit dashboard
- Input validation, structured logging, tests, Dockerfile, and CI workflow

## Quick start (Python 3.11 recommended)
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python scripts/train_model.py
uvicorn app.main:app --reload
```
API docs: http://127.0.0.1:8000/docs

In another terminal:
```bash
streamlit run dashboard.py
```

## Example API request
```bash
curl -X POST "http://127.0.0.1:8000/predict" -H "Content-Type: application/json" -d '{
  "amount": 2499.0,
  "payment_attempts": 3,
  "hours_since_failure": 18,
  "customer_tenure_days": 240,
  "previous_success_rate": 0.72,
  "is_subscription": true,
  "invoice_age_days": 0,
  "cart_value": 2499.0,
  "payment_method": "card",
  "failure_code": "do_not_honor",
  "contact_count_24h": 0,
  "customer_opted_out": false,
  "payment_already_succeeded": false
}'
```

## Endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/health` | Service and model status |
| POST | `/predict` | Risk score and recommended action |
| POST | `/cases` | Predict and save a case |
| GET | `/cases` | List saved cases |
| GET | `/cases/{case_id}` | Get a saved case |
| POST | `/cases/{case_id}/simulate-recovery` | Simulate outcome and write audit event |

## Input fields
`amount`, `payment_attempts`, `hours_since_failure`, `customer_tenure_days`, `previous_success_rate`, `is_subscription`, `invoice_age_days`, `cart_value`, `payment_method`, `failure_code`, `contact_count_24h`, `customer_opted_out`, `payment_already_succeeded`.

Payment methods: `card`, `upi`, `wallet`, `bank_transfer`, `other`. Failure codes: `insufficient_funds`, `do_not_honor`, `expired_card`, `network_error`, `authentication_required`, `unknown`.

## Responsible-use safeguards
- Stop when payment is confirmed successful or the customer opted out.
- Do not recommend more contacts after the configured contact cap.
- This project does not send messages, charge cards, or connect to a payment gateway.
- For real deployment, add authentication, authorization, secrets management, monitoring, privacy review, data-retention rules, and human approval for consequential actions.

## Tests
```bash
pytest -q
```

## Docker
```bash
docker build -t recoverai .
docker run --rm -p 8000:8000 recoverai
```

## GitHub submission
```bash
git init
git add .
git commit -m "Build RecoverAI revenue recovery intelligence platform"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```
Before submitting, run the tests, add your name/internship details if required, and include screenshots of the API docs and dashboard.
